# RLDetect

RLDetect is a BakkesMod plugin for Rocket League.

## Installation

1. Extract this archive.
2. Copy **RLDetect.dll** to:

   `%APPDATA%\bakkesmod\bakkesmod\plugins`

3. Start **BakkesMod** and launch **Rocket League**.

## Enabling the Plugin

1. Press **F2** in-game to open the BakkesMod menu.
2. Open the **Plugins** tab.
3. In **Plugin Manager**, locate **RLDetect**.
4. Enable/load the plugin.

## Default Hotkeys

- **F7**: Open RLDetect
- **F8**: Mark the current match for analysis

## Troubleshooting

If RLDetect does not show up, verify that the DLL is in the correct folder and restart both BakkesMod and Rocket League.